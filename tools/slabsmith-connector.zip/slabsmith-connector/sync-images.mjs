#!/usr/bin/env node
/**
 * sync-images.mjs — discover Slabsmith slab images and write a JSON manifest (no upload).
 *
 * Usage:
 *   node sync-images.mjs --config config.json
 *
 * Also available as:
 *   node sync-slabs.mjs --config config.json --image-manifest
 */

import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

import {
  appendLogLine,
  inspectSourceXml,
  loadConfig,
  resolveConfigPath,
  validateManifestConfig,
  writeJsonArtifact,
} from "./connector-shared.mjs";
import {
  discoverImageManifest,
  formatManifestSummaryLines,
} from "./image-manifest.mjs";

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * @param {string[]} argv
 */
export function parseImageManifestArgs(argv) {
  /** @type {{ configPath: string|null, help: boolean }} */
  const out = { configPath: null, help: false };
  const args = argv.slice(2);
  for (let i = 0; i < args.length; i += 1) {
    const arg = args[i];
    if (arg === "--help" || arg === "-h") {
      out.help = true;
      continue;
    }
    if (arg === "--image-manifest") {
      continue;
    }
    if (arg === "--config") {
      const next = args[i + 1];
      if (!next || next.startsWith("-")) throw new Error("--config requires a path");
      out.configPath = next;
      i += 1;
      continue;
    }
    throw new Error(`Unknown argument: ${arg}`);
  }
  return out;
}

/**
 * @param {string[]} [argv]
 * @param {{ discoverImageManifest?: typeof discoverImageManifest }} [deps]
 */
export async function runImageManifest(argv = process.argv, deps = {}) {
  const discover = deps.discoverImageManifest ?? discoverImageManifest;
  const { configPath, help } = parseImageManifestArgs(argv);

  if (help) {
    console.log(`Slabsmith image manifest (discovery only; no upload)

Usage:
  node sync-images.mjs --config config.json
  node sync-slabs.mjs --config config.json --image-manifest

Config:
  sourceXmlPath   Slabsmith export XML (required)
  imageRootPath   Folder with <SlabID>.jpg files (default: C:\\slabcloud)
  logDir          Writes image-manifest-<timestamp>.json here
`);
    return 0;
  }

  const cfgPath = configPath || join(__dirname, "config.json");
  const { config } = loadConfig(cfgPath);
  const validated = validateManifestConfig(config);

  const startedAt = new Date().toISOString();
  const log = (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    appendLogLine(validated.logDir, line);
  };

  log(`image manifest start config=${cfgPath}`);

  const xmlInfo = inspectSourceXml(validated.sourceXmlPath);
  const imageRootAbs = resolveConfigPath(validated.imageRootPath);
  log(`source xml path=${xmlInfo.path} bytes=${xmlInfo.bytes} modified=${xmlInfo.modifiedAt}`);
  log(`image root path=${imageRootAbs}`);

  const xml = readFileSync(xmlInfo.path, "utf8");
  if (!xml.trim()) {
    throw new Error("Source XML file is empty");
  }

  const manifest = discover({
    xml,
    sourceXmlPath: xmlInfo.path,
    imageRootPath: imageRootAbs,
  });

  const artifact = writeJsonArtifact(validated.logDir, "image-manifest", manifest);
  if (artifact.written) {
    log(`manifest written path=${artifact.path}`);
  } else {
    log("manifest not written (logDir not configured)");
  }

  for (const line of formatManifestSummaryLines(manifest.summary)) {
    log(line);
  }

  log(`image manifest end started=${startedAt}`);
  return 0;
}

export async function runImageManifestCli(argv = process.argv) {
  try {
    const code = await runImageManifest(argv);
    process.exitCode = code ?? 0;
  } catch (err) {
    console.error(`[slabsmith-connector] fatal: ${String(err?.message || err)}`);
    process.exitCode = 1;
  }
}

const isMain =
  process.argv[1] &&
  fileURLToPath(import.meta.url) === resolve(process.argv[1]);

if (isMain) {
  runImageManifestCli();
}
